<?php
?>
<div class="navbar">
    <a href="/">Home</a>
</div>
